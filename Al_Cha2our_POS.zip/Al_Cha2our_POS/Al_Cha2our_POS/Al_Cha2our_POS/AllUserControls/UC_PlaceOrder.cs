﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Al_Cha2our_POS.AllUserControls
{
    public partial class UC_PlaceOrder : UserControl
    {
        public UC_PlaceOrder()
        {
            InitializeComponent();
        }

        private void UC_PlaceOrder_Load(object sender, EventArgs e)
        {

        }
    }
}
