﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Al_Cha2our_POS.AllUserControls
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        int num = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            if(num==0)
            {
                labelBanner.Location = new Point(94,367);
                labelBanner.ForeColor = Color.Orange;
                num++;

            }
            else if(num==1)
            {
                labelBanner.Location = new Point(166, 367);
                labelBanner.ForeColor = Color.Green;
                num++;
            }
            else if (num==2)
            {
                labelBanner.Location = new Point(268, 367);
                labelBanner.ForeColor = Color.RoyalBlue;
                num = 0;


            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
